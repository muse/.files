--[[                            
     2033 Awesome WM config.
     www.github.com/Imakethings/2033                                  
--]]

theme                               = {}

-- Configure the home directory and the location of the background.
theme.confdir                       = os.getenv("HOME") .. "/.config/awesome/themes/2033"
theme.wallpaper                     = "~/Pictures/Backgrounds/futile.png"

-- My currently used font.
theme.font                          = "GohuFont 9"

-- All the colors we use in this theme.
background_darkest                  = "#131313"
background_darker                   = "#222222"
background_dark                     = "#363636"

border_light                        = "#222220"
border_dark                         = "#111110"

foreground_lightest                 = "#BBFFDD"
foreground_lighter                  = "#BBEECC"
foreground_light                    = "#BBEEBB"

-- Navbar
theme.bg_normal                     = background_dark
theme.bg_focus                      = background_darker
theme.bg_urgent                     = background_darkest

theme.fg_normal                     = foreground_light
theme.fg_focus                      = foreground_lightest
theme.fg_urgent                     = foreground_lighter

-- Applications
theme.border_width                  = "1"
theme.border_normal                 = border_light 
theme.border_focus                  = border_dark
theme.border_marked                 = border_dark

-- MOD4 + W
theme.menu_width                    = "160" 
theme.menu_border_width             = "0" 
theme.menu_fg_normal                = foreground_lightest
theme.menu_fg_focus                 = foreground_light
theme.menu_bg_normal                = background_darkest
theme.menu_bg_focus                 = background_dark

theme.tasklist_disable_icon         = true
theme.tasklist_floating             = ""
theme.tasklist_maximized_horizontal = ""
theme.tasklist_maximized_vertical   = ""

theme.useless_gap_width		        = 10

return theme
