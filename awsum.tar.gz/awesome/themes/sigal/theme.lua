theme = {}

theme.font          = "GohuFont 9"

theme.bg_normal     = "#1E1E1E"
theme.bg_focus     	= "#2F2F2F" 
theme.bg_urgent     = theme.bg_normal
theme.bg_minimize   = theme.bg_normal
theme.bg_systray    = theme.bg_normal

theme.fg_normal     = "#E0E0E0"
theme.fg_focus     	= "#CBCBCB"
theme.fg_urgent     = theme.fg_normal
theme.fg_minimize   = theme.fg_normal

-- Remove these lines to set a border around your windows.
theme.border_width  = 0
-- theme.border_normal = "#E3DCE5"
-- theme.border_focus  = "#FEFDFF" 
-- theme.border_marked = "#FEFDFF"

theme.useless_gap_width = 10


theme.menu_bg_normal = "#282333" --0B0B12
theme.menu_bg_focus = "#524C59" --BAB3D0 151324

theme.menu_fg_normal = "#aaa5ad"
theme.menu_fg_focus = "#d6ccdc"

theme.menu_border_width = 0
theme.menu_border_color = "#ECE1E7" --#0B0B12

theme.menu_submenu_icon = "~/.config/awesome/theme/submenu4.png"
theme.menu_height = 15
theme.menu_width  = 105


--theme.wallpaper = config_dir .. "/theme/wallpaper-1624678.jpg"

return theme

