-- An awesome window manager configuration.
-- Version 3.5.4
-- Owner <Mirko van der waal>
-- Contact <mvdw at airmail dot cc>
-- Description This theme makes use of various additional packages.
-- These are to be obtained with your distros package-manager.
-- * Vicious 

gears 			= require("gears")
awful 			= require("awful")
awful.rules 	= require("awful.rules")
awful.autofocus = require("awful.autofocus")
vicious   		= require("vicious")
wibox 			= require("wibox")
center			= require("wibox.center")
beautiful 		= require("beautiful")
naughty 		= require("naughty")
meunbar 		= require("menubar")


-- Run something once and usually on statup.
function once(cmd)
	findme = cmd
	firstpace = cmd:find(" ")
	if firstspace then
		findme = cmd:sub(0, firstspace - 1)
	end
	awful.util.spawn_with_shell(
		"pgrep -u $USER -c " .. findme .. " > /dev/null || (" .. cmd .. ")"
	)
end

-- Detect any startup errors here.
if awesome.startup_errors then
	naughty.notify({
		preset = naughty.config.presets.critical,
		title  = "You messed up!",
		text   = awesome.startup_error
	})
end

-- Detect errors while active, these are usually thrown
-- When unknown keybinds are pressed or when a unknown command is ran.
do 
	stderr = false
	awesome.connect_signal("debug::error", function(err)
		-- We only want to see said error once.
		if stderr then return end
		stderr = true
		
		naughty.notify({
			preset = naughty.config.presets.critical,
			title  = "You messed up!",
			text   = err	
		})

		stderr = false
	end)
end

-- Core variables for the manager to use.
-- The os.getenv(VARIABLE) relies on exported variables.
-- Some are default the others are made by adding them to your .$SHELL.
home 		= os.getenv("HOME") 
config		= os.getenv("AWESOME") or home .. "/.config/awesome"
editor 		= os.getenv("EDITOR") or "vim" or "vi"
browser 	= os.getenv("BROWSER") or "firefox"
terminal 	= "urxvt"
modkey 		= "Mod4"
altkey 		= "Mod1"

-- Initialise the theme file.
beautiful.init(config .. "/themes/sigal/theme.lua")

-- Add any layouts you wish to use here.
local layouts = {
	awful.layout.suit.floating
}

-- Alligns the windows with a layout upon start.
tags = {
	layout 	= { layouts[1], layouts[1], layouts[1]},
	names 	= {"1", "2", "3"}
}

-- This will write the wallpaper to every available screen.
if beautiful.wallpaper then
	for scr = 1, screen.count() do
		-- Change "true" with "false" to honor the aspect ratio.	
		gears.wallpaper.maximized(beautiful.wallpaper, s, true)
	end	
end

-- Here we create & costumize the menu.
menu_break		= string.rep("\n", 1)
menu_internet	= {
	{"Firefox", browser},	
	{"Chromium","/usr/bin/chromium"},
	{"Lynx", 	terminal .. " -g 100x64 -e lynx"},
}
menu_media 		= {
	{"MPV", 	"mpv"},
	{"NCMPCPP", terminal .. " -g 100x32 -e ncmpcpp"},
	{menu_break,""},
	{"Volume", 	terminal .. " -g 100x32 -e alsamixer"},
}
menu_graphics	= {
	{"Gimp", 	"gimp"},
	{"Feh", 	"feh /home/mvdw/Pictures/"},
}
menu_system 	= {
	{"Process", terminal .. " -g 100x32 -e htop"},
	{menu_break,""},
	{"Logout", 	"killall awesome"},
	{"Shutdown","shutdown -h now"},
	{"Reboot", 	"reboot"},
}	
menu_all = awful.menu({
	items = {
		{"Internet",menu_internet},
		{"Media", 	menu_media},
		{"Graphics",menu_graphics},
		{"System",	menu_system},
	}
})

-- Initialise the launcher. It is now ready to be bound later.
launcher = awful.widget.launcher({
	menu = menu_all,
})

-- widget_clock 	= awful.widget.textclock("<span>%a %d %b %H%M</span>")
--widget_uptime 	= wibox.widget.textbox()
--widget_system 	= wibox.widget.textbox()
--widget_cpu 		= wibox.widget.textbox()
--widget_mem 		= wibox.widget.textbox()
--widget_space 	= wibox.widget.textbox()
--widget_space:set_text("   ")

--vicious.register(widget_uptime, vicious.widgets.uptime, "<span>$1$2$3</span>")
--vicious.register(widget_system, vicious.widgets.os, "<span>$1$2</span>")
--vicious.register(widget_cpu, vicious.widgets.cpu, "<span>$1$2</span>", 3)
--vicious.register(widget_mem, vicious.widgets.mem, "<span>$1$2</span>", 5)

