> Doubt is not a pleasant condition, but certainty is absurd.
> - Voltaire
