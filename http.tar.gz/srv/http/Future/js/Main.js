/*
 * Main.js
 * Copyright (C) 2015 mvdw <mvdw at airmail dot cc>
 *
 * Distributed under terms of the MIT license.
 */


var ftr = new Future(".ftrimg", "images/landscape.png")

ftr.add("waters", {
        _uuid: null,        /* Create a set UUID. */
        _id: null,          /* Create a set ID */
        _value  : 0,        /* Define a starting value, relates to _images. */
        _images : { 0:"images/grandma.png",                                     
                    1:"images/people.png",                                      
                    2:"images/trees.png"}, /* Set the images and their locations. */
        _x: 50,             /* The location on the X axis. */
        _y: 100             /* The location on the Y axis. */
    });

ftr.add("trees", {
        _uuid: null,        /* Create a set UUID. */
        _id: null,          /* Create a set ID */
        _value  : 2,        /* Define a starting value, relates to _images. */
        _images : { 0:"images/grandma.png",                                     
                    1:"images/people.png",                                      
                    2:"images/trees.png"}, /* Set the images and their locations. */
        _x: 100,             /* The location on the X axis. */
        _y: 100             /* The location on the Y axis. */
    });


ftr.modify("waters", {
        _x: 0,
    })

ftr.reload()              /* Reload the canvas for drawing. */

