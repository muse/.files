/*
 * Question.js
 * Copyright (C) 2015 mvdw <mvdw@arch>
 *
 * Distributed under terms of the MIT license.
 */

/**
 * Create a new question.
 *
 * @arg {string} question - The question to be asked.
 * @arg {array} yes - An array containing the reply name and an effects object.
 * @arg {array} no - An array containing the reply name and an effects object.
 * @constructor
 */
var Question = function(el, val)
{
    this.el = (function(el){
        var _el = {
            _question   : document.querySelector(el._question) || undefined,
            _false      : document.querySelector(el._false)    || undefined,
            _true       : document.querySelector(el._true)     || undefined,
        }
        return _el; })(el);
    
    this.val = (function(val){
        var _val = {
            _question   : val._question || undefined,
            _false      : val._false    || undefined,
            _true       : val._true     || undefined,
        }
        return _val; })(val);

    this.n = this.el._true.addEventListener("click", function(){ return true });
    this.n = this.el._false.addEventListener("click", function(){ return false });
}

Question.prototype.load = function()
{
    for(_ in this.el)
    {
        console.log(this.el[_])
        this.el[_].innerHTML = this.val[_]
    }
}

var Question = function(question, bool)
{
    this.modifiers = (function(bool){
        var _ = {
            _false : bool._false    || undefined,
            _true  : bool._true     || undefined,
            _nill  : bool._question || undefined,
        }; return _; })(bool);
}

Question.prototype.attach = function(el)
{
    this.el = (function(el){
        var _ = {
            _question   : document.querySelector(el._question) || undefined,
            _false      : document.querySelector(el._false)    || undefined,
            _true       : document.querySelector(el._true)     || undefined,
        }; return _; })(el);
}

Question.prototype.events = function()
{
    if (!arg)
        return
}

var a = new Question({
        _question   : ".ques",
        _false      : ".butt-false",
        _true       : ".butt-true",
    },{
        _question   : "Who is this mad man?",
        _false      : "Herman",
        _true       : "Bob",
        }).load();

//;a.load()


