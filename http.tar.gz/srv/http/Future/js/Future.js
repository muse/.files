/*
 * Future.js
 * Copyright (C) 2015 mvdw <mvdw at airmail dot cc>
 *
 * Distributed under terms of the MIT license.
 */

/**
 * The core creation of the future element.
 *
 * @arg {string} el - The element name of (an) canvas.
 * @arg {string} bg - The relative path to the background.
 * @constructor
 */
var Future = function(el, bg)
{
    /* The raw canvas element. */
    this.element = (function(el) {
        return document.querySelector(el) !== undefined ? document.querySelector(el) : undefined; })(el);
    
    /* The context of the canvas element, this is where we draw on. */
    this.ctx = (function(el) {
        return el.getContext !== null || undefined ? el.getContext("2d") : undefined; })(this.element);
    
    /* The default background we will use, you don't want to draw on white. */
    this.background = bg;
    /* All the elements which will be appended to the context.  */
    this.layers = {};
}

/**
 * Adding a new element to the layer.
 * 
 * @arg {string} call - The callback name to identify it.
 * @arg {object} attr - The object containing the images specific values.
 */
Future.prototype.add = function(call, attr)
{
    /* This way we do not require all of the parameters to be set but 
       But allow any amount of elements. It makes setting defaults easier as well. */
    _attr = {
        _uuid   : attr._uuid    || null,
        _id     : attr._id      || null,
        _images : attr._images  || {}, 
        _value  : attr._value   || 0,
        _x      : attr._x       || 0,
        _y      : attr._y       || 0,
    }; 

    /* Assign a new entry taking it doesn't exist already. */
    if(!this.layers.hasOwnProperty(call))
        this.layers[call] = _attr;
}

/**
 * Change a value of an already set layer.
 * 
 * @arg {string} call - The callback name to identify it.
 * @arg {object} attr - The object containing new values.
 */
Future.prototype.modify = function(call, attr)
{       
    for (val in attr)
        if (this.layers[call][val] !== undefined)
            this.layers[call][val] = attr[val];
}

/**
 * Prepare an writable context image.
 *
 * @arg {object} attr - new Image() attributes in object format.
 */
Future.prototype.prepare = function(attr)
{
    var image = new Image();
    for (val in attr)
        if(image[val] !== undefined)
            image[val] = attr[val];
    return image
}

/**
 * Reload the values to the canvas.
 */ 
Future.prototype.reload = function()
{
    /* Empty the canvas entirely for re-writing. */
    this.ctx.clearRect(0, 0, this.element.height, this.element.width)      
    
    /* First of all, draw the background. */
    this.ctx.drawImage(this.prepare({ src: this.background, }), 0, 0) 

    for(layer in this.layers)
        this.ctx.drawImage(this.prepare({
            src: this.layers[layer]._images[this.layers[layer]._value]
            }), this.layers[layer]._x, this.layers[layer]._y);
}
